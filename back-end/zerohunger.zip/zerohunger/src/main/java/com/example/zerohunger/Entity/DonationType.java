package com.example.zerohunger.Entity;

public enum DonationType {
	FOOD,
	APPLIANCE,
	CLOTHING
}
