package com.example.zerohunger.Entity;

public enum Foodtype {
	VEGAN,
	HALAL,
	VEGETARIAN,
	NUT_FREE,
	EGG_FREE

}
