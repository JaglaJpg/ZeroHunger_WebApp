package com.example.zerohunger.Entity;

public enum DonationStatus {
	PENDING,
	ONGOING,
	DELIVERED
}
